using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace WindowsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void importToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "C:\\Users\\Phil\\Desktop";
             openFileDialog1.Filter = "TXT files (*.txt)|*.txt";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader reader;
                try
                {
            
                    if ((myStream = openFileDialog1.OpenFile()) != null)
                    {

                        using (myStream)
                        {
                            reader = new StreamReader(myStream);
                            string line;

                            while ((line = reader.ReadLine()) != null)
                            {
                                if (line.IndexOf("-",0) > 0 && line.IndexOf("-")<5 )
                                {
                           
                                    line = line.Trim();
                                    int end = line.IndexOf("-",0);
                                    if (line.Substring(0, 1) == "0" || !IsNumeric(line.Substring(0, end))) { }
                                    else
                                    {
                                        string data = line;
                                        string num = line.Substring(0, end);
                                    readdata(num,data);
                                    }
                                }
                           //     MessageBox.Show(line);
                                Application.DoEvents();


                            }
                        }
                    }
                }
                catch (Exception ex) { MessageBox.Show(ex.ToString()); }
            }
        }

 
        public void readdata(string num,string data)
        {

           
            int st=0;
            int end=0;

            string name = "";
            string address = "";
            string zip = "";
            string activite = "";
            string forme = "";
            string origine = "";
            string administration = "";
            string date = "";
            bool err=true;
            bool act = true;

            //nom commercial        
            try
            {
                st = data.IndexOf("Nom commercial :") + 16;
                end = data.IndexOf(".", st);
                if (st > 16 && end > 0 && end > st)
                {
                    name = data.Substring(st, end - st).Trim();
                    if (name != "")
                    {
                        //  MessageBox.Show("1) "+name);
                        err = false;
                    }
                }

                if (err == true)
                {
                    st = data.IndexOf("Sigle :") + 7;
                    end = data.IndexOf(".", st);
                    if (st > 7 && end > 0 && end > st)
                    {
                        name = data.Substring(st, end - st).Trim();
                        if (name != "")
                        {
                            //  MessageBox.Show("2) " + name);
                            err = false;
                        }
                    }
                }
                if (err == true)
                {
                    st = data.IndexOf("Nom d�usage :") + 13;
                    end = data.IndexOf(".", st);
                    if (st > 13 && end > 0 && end > st)
                    {
                        name = data.Substring(st, end - st).Trim();
                        if (name != "")
                        {
                            //   MessageBox.Show("3) " + name);
                            err = false;
                        }
                    }
                }

                if (err == true)
                {
                    end = data.IndexOf(". Forme", st);
                    if (end < 1) { end = data.IndexOf("."); };
                    if (end > 0) { st = data.Substring(0, end).LastIndexOf('.') + 1; }
                    // MessageBox.Show("st:" + st.ToString() + " end:" + st.ToString());
                    if (st > 1 && end > 0 && end > st)
                    {
                        name = data.Substring(st, end - st).Trim();
                        if (name != "")
                        {
                            //  MessageBox.Show("4) " + name);
                            err = false;
                        }
                    }
                }
           
            

               //adresse
                if (data.IndexOf("Adresse :") > 0)
                {
                    st = data.IndexOf("Adresse :")+9;
                    end = data.IndexOf(".", st);
                    if (st + end > 0 && end > st) { address=data.Substring(st, end - st).Trim(); }
                }

            //zipcode
            if(address!=""){

                Match match = Regex.Match(address, @"\d{5}",  RegexOptions.IgnoreCase);

	// Here we check the Match instance.
	if (match.Success)
	{
        zip = (match.Groups[0].Value).Substring(0, 2);
    }

            }

            //activit�
            if (data.IndexOf("Activit� :") > 0)
            {
                st = data.IndexOf("Activit� :")+ 10;
                end = data.IndexOf(".", st);
                activite = data.Substring(st, end - st);

            }
            if (data.IndexOf("Forme :") > 0)
            {
                st = data.IndexOf("Forme :") + 7;
                end = data.IndexOf(".", st);
                forme = data.Substring(st, end - st);

            }
            if (data.IndexOf("Origine du fonds :") > 0)
            {
                st = data.IndexOf("Origine du fonds :") + 18;
                end = data.IndexOf(".", st);

                if (st > 18 && end > 0 && end > st)
                {
                    origine = data.Substring(st, end - st).Trim();
                  //  if (origine.Length>7 && origine.Substring(0, 8) == "Cr�ation") { origine = "Cr�ation"; }
                  //  if (origine.Length>66 && origine.Substring(0, 67) == "Immatriculation d�une personne physique suite � cr�ation d�un fonds") { origine = "Cr�ation"; }

              
                }

            }
            if (data.IndexOf("Administration :") > 0)
            {
                st = data.IndexOf("Administration :") + 16;
                end = data.IndexOf(".", st);
                administration = data.Substring(st, end - st);

            }

            if (data.IndexOf("Date de commencement d�activit� :") > 0)
            {
                st = data.IndexOf("Date de commencement d�activit� :") + 33;
                end = data.IndexOf(".", st);
                date = data.Substring(st, end - st);

            }
        
            
            

                if (name != "" && address != "")
                {

                   
                    ListViewItem item = listView1.Items.Add(num);
                    item.SubItems.Add(name);
                    item.SubItems.Add(address);
                    item.SubItems.Add(zip);

                    if(activite!=""){
                        item.SubItems.Add(activite); act = false;
                    }else if(forme!=""){
                        item.SubItems.Add(forme); act = false;
                    }
                    if (act == true) { item.SubItems.Add(""); }
                   
                    item.SubItems.Add(origine);            
                    item.SubItems.Add(administration);
                    item.SubItems.Add("");
                    item.SubItems.Add(date);   

                }
                else
                {
                    //show error
                 //   ListViewItem item = listView1.Items.Add(num);
                 //   item.SubItems.Add("error");
                }
           


            }
            catch (Exception e) { //MessageBox.Show(e.Message);
            }
       

        }



        public static System.Boolean IsNumeric (System.Object Expression)
{
    if(Expression == null || Expression is DateTime)
        return false;

    if(Expression is Int16 || Expression is Int32 || Expression is Int64 || Expression is Decimal || Expression is Single || Expression is Double || Expression is Boolean)
        return true;

    try 
    {
        if(Expression is string)
            Double.Parse(Expression as string);
        else
            Double.Parse(Expression.ToString());
            return true;
        } catch {} // just dismiss errors but return false
        return false;
    }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if ( listView1.SelectedIndices.Count <= 0)
            {
                return;
            } 
            int i = listView1.SelectedIndices[0];

            panel1.Visible = true;
          
           
            textBox1.Text=listView1.Items[i].SubItems[1].Text + ", " + listView1.Items[i].SubItems[2].Text+" t�l�phone";

            inputphone.Text = listView1.Items[i].SubItems[7].Text;

            mem.Text = i.ToString();
            
        }

        private void injectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            inject();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void readAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            read("","","");
         
        }

        //string datasrc = "E:\\BACKUP-E\\Phil\\Documents\\Visual Studio 2005\\Projects\\BODAC\\Backup\\BODAC\\bodac.mdf";

        private void inject()
        {

            SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=E:\\BACKUP-E\\Phil\\Documents\\Visual Studio 2005\\Projects\\BODAC\\Backup\\BODAC\\bodac.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");

            connection.Open();
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                string _bodac_id = listView1.Items[i].SubItems[0].Text;
                string _name = listView1.Items[i].SubItems[1].Text;
                string _address = listView1.Items[i].SubItems[2].Text;
                string _dept = listView1.Items[i].SubItems[3].Text;
                string _activite = listView1.Items[i].SubItems[4].Text;
                string _origine = listView1.Items[i].SubItems[5].Text;
                string _administration = listView1.Items[i].SubItems[6].Text;
                string _phone = listView1.Items[i].SubItems[7].Text;
                string _date = listView1.Items[i].SubItems[8].Text;


                SqlCommand cmd = new SqlCommand("SELECT count(*) FROM BODACC where (company=@Name and bodac_id=@Bodac_id)", connection);
                SqlParameter param = new SqlParameter();
                param.ParameterName = "@Name";
                param.Value = _name;
                cmd.Parameters.Add(param);
                param = new SqlParameter();
                param.ParameterName = "@Bodac_id";
                param.Value = _bodac_id;
                cmd.Parameters.Add(param);

                int count = (int)cmd.ExecuteScalar();
                if (count > 0) { }
                else
                {
                    //insert
                    cmd = new SqlCommand("INSERT INTO BODACC(company,address,dept,description,origine,administration,phone,date, bodac_id) values (@Name,@Address,@Dept,@Activite,@Origine,@Administration,@Phone,@Date,@Bodac_id)", connection);
                    param = new SqlParameter();
                    param.ParameterName = "@Name";
                    param.Value = _name;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@Address";
                    param.Value = _address;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@Dept";
                    param.Value = _dept;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@Activite";
                    param.Value = _activite;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@Origine";
                    param.Value = _origine;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@Administration";
                    param.Value = _administration;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@Phone";
                    param.Value = _phone;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@Date";
                    param.Value = _date;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@Bodac_id";
                    param.Value = _bodac_id;
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            }
            connection.Close();
           // MessageBox.Show("Database updated");

        }

        private void read(string search, string dept, string datee)
        {

            string msearch = search;
            string rmsearch = "";
            string add = "";

            if (msearch.IndexOf(",") > 0)
            {
               string [] rsearch = msearch.Split(new char[] { ',' });

               if (rsearch[1] != "") { rmsearch = rsearch[1]; add += " and description like '%'+@Description+'%' "; search = rsearch[0]; }
            }
         


            pictureBox1.Visible = true;
            Application.DoEvents();
            listView1.Items.Clear();

            string desc="";

            string l = "";
            

            if(datee!=""){
                add+=" and date like '%'+@Date+'%' ";
            }


            SqlCommand cmd;

            SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=" + datasrc + ";Integrated Security=True;Connect Timeout=30;User Instance=True");
            connection.Open();

           
            if (dept != "")
            {
                if (dept.Length == 2)
                {
                    cmd = new SqlCommand("SELECT company,address,dept,description,origine,administration,phone,date, id, number FROM BODACC where (company like '%'+@Search+'%' or address like '%'+@Search+'%' or description like '%'+@Search+'%' or origine=@Search or administration like '%'+@Search+'%' or phone=@Search or date=@Search) and dept=@Dept and number is not null " + add + " ORDER BY address, number", connection);//1749
                }
                else {
                    cmd = new SqlCommand("SELECT company,address,dept,description,origine,administration,phone,date, id, number FROM BODACC where (company like '%'+@Search+'%' or description like '%'+@Search+'%' or origine=@Search or administration like '%'+@Search+'%' or phone=@Search or date=@Search) and address like '%'+@Dept+'%' and number is not null " + add + " ORDER BY address, number", connection);//1749             
                }
            }
            else
            {

                cmd = new SqlCommand("SELECT company,address,dept,description,origine,administration,phone,date, id, number FROM BODACC where (company like '%'+@Search+'%' or address like '%'+@Search+'%' or description like '%'+@Search+'%' or origine=@Search or administration like '%'+@Search+'%' or phone=@Search or date=@Search) and number is not null " + add + " ORDER BY address, number", connection);//1749
            }
                
                SqlParameter param = new SqlParameter();
            param.ParameterName = "@Search";
            param.Value = search;
            cmd.Parameters.Add(param);

            if (rmsearch != "")
            {
                param = new SqlParameter();
                param.ParameterName = "@Description";
                param.Value = rmsearch;
                cmd.Parameters.Add(param);
            }

            if (dept != "")
            {
                param = new SqlParameter();
                param.ParameterName = "@Dept";
                param.Value = dept;
                cmd.Parameters.Add(param);
            }
            if (datee != "")
            {
                param = new SqlParameter();
                param.ParameterName = "@Date";
                param.Value = datee;
                cmd.Parameters.Add(param);
            }

            SqlDataReader rdr = cmd.ExecuteReader();
            Application.DoEvents();
            while (rdr.Read())
            {
                ListViewItem item = listView1.Items.Add((string)rdr["id"].ToString());
                item.SubItems.Add((string)rdr["company"]);

                try
                {
                    if ((string)rdr["number"] != string.Empty && rdr["number"] != null) { l = (string)rdr["number"].ToString(); } else { l = ""; }
                    l += " " + (string)rdr["address"];
                }
                catch (Exception ex) { }
                item.SubItems.Add(l);
                item.SubItems.Add((string)rdr["dept"]);

                string descc=(string)rdr["description"].ToString().ToLower().Trim();
                if (descc.IndexOf("immobili") > -1 || descc.IndexOf("immeuble") > -1) { desc = "immobilier"; } else { desc = descc; }
                if (descc.IndexOf("bar ") > -1 || descc.IndexOf("caf�") > -1 || descc.IndexOf("brasserie") > -1) { desc = "brasserie"; } else { desc = descc; }
                if (descc.IndexOf("restaurant") > -1) { desc = "restaurant"; } else { desc = descc; }

                desc = desc.Trim();
                item.SubItems.Add(desc);

                string ori = (string)rdr["origine"].ToString().ToLower();

               // if (ori.IndexOf("cr�ation") > -1) { ori = "cr�ation"; }
              //  if (ori.IndexOf("achat") > -1) { ori = "achat"; }
             //   if (ori.IndexOf("acqui") > -1) { ori = "achat"; }
              //  if (ori.IndexOf("location") > -1) { ori = "location"; }
                item.SubItems.Add(ori);

                string admin = (string)rdr["administration"].ToString().ToLower();
               admin= admin.Replace("g�rant", "");
               admin = admin.Replace("associ�", "");
               admin = admin.Replace("pr�sident", "");
               admin = admin.Replace(":", "");
               admin = admin.Replace(",", " ");
               admin = admin.Replace("  ", " ");
               admin = admin.Trim();
                item.SubItems.Add(admin);
                item.SubItems.Add((string)rdr["phone"]);
                item.SubItems.Add((string)rdr["date"]);

               

               // label1.Text = "Results : " + listView1.Items.Count.ToString();
          

            }

            label1.Text = "Results : "+ listView1.Items.Count.ToString();
            Application.DoEvents();

            if (mem.Text != "")
            {
                if (listView1.Items.Count > int.Parse(mem.Text))
{
                listView1.Items[int.Parse(mem.Text)].Selected = true;
                listView1.Select();
                mem.Text = "";
}
            }
            pictureBox1.Visible = false;
            Application.DoEvents();
        }

     

        private void button4_Click(object sender, EventArgs e)
        {
            if (inputsearch.Text != "" || dept.Text!="")
            {
                read(inputsearch.Text, dept.Text, date.Text);

            }
        }


        private void button1_Click(object sender, EventArgs e)//save phone number
        {
            if (listView1.SelectedIndices.Count <= 0)
            {
                return;
            }
            int i = listView1.SelectedIndices[0];

            string id = listView1.Items[i].SubItems[0].Text;

            if (inputphone.Text != "")
            {
                SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=" + datasrc + ";Integrated Security=True;Connect Timeout=30;User Instance=True");
                connection.Open();

              SqlCommand cmd = new SqlCommand("UPDATE BODACC SET phone=@Phone where id=@Id", connection);// 1 =french
              SqlParameter  param = new SqlParameter();
                param.ParameterName = "@Phone";
                param.Value = inputphone.Text;
                cmd.Parameters.Add(param);
                param = new SqlParameter();
                param.ParameterName = "@Id";
                param.Value = id;
                cmd.Parameters.Add(param);
                cmd.ExecuteNonQuery();

            }
       
            read(inputsearch.Text, dept.Text, date.Text);

            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string q = textBox1.Text;
            MessageBox.Show(q);

        }

        private void clearAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }

        private void autoToolStripMenuItem_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                textBox2.Text = listBox1.Items[i].ToString();
                Application.DoEvents();

                StreamReader reader = new StreamReader(listBox1.Items[i].ToString());
            string line;

            while ((line = reader.ReadLine()) != null)
            {
                if (line.IndexOf("-", 0) > 0 && line.IndexOf("-") < 5)
                {

                    line = line.Trim();
                    int end = line.IndexOf("-", 0);
                    if (line.Substring(0, 1) == "0" || !IsNumeric(line.Substring(0, end))) { }
                    else
                    {
                        string data = line;
                        string num = line.Substring(0, end);
                        readdata(num, data);
                    }
                }
                //     MessageBox.Show(line);
              
 
              //  Application.DoEvents();

                

            }
            inject(); Application.DoEvents();
            listView1.Items.Clear(); Application.DoEvents();
            }
        }

        private void loadFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string ii = "";
      
            for (int i = 118; i < 134; i++)
            {
                if (i < 10) { ii = "00"; }
                if (i >= 10 && i < 100) {  ii = "0"; }
                if (i >= 100) { ii = ""; }
                string file = "C:\\Users\\Phil\\Desktop\\BODACC\\EBODACC-A_20140" +ii+ i + "_0001_p000.txt";

                listBox1.Items.Add(file);

            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // string data = "<table>";
            string data = "";
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                //   data += "<tr>";
                //  data += "<td width='10%'>";
                data += listView1.Items[i].SubItems[1].Text;//company
                // data+= "</td><td width='15%'>";
                data += "|";
                data += listView1.Items[i].SubItems[2].Text;//adress
                //data += "</td><td width='20%'>";
                data += "|";

                if (listView1.Items[i].SubItems[4].Text.Length > 50)
                {
                    data += listView1.Items[i].SubItems[4].Text.Substring(0, 50);//activite
                }
                else
                {
                    data += listView1.Items[i].SubItems[4].Text;//activite

                }
                data += "|";

                if (listView1.Items[i].SubItems[5].Text.Length > 10000)
                {
                    data += listView1.Items[i].SubItems[5].Text.Substring(0, 10);//origine
                }
                else
                {
                    data += listView1.Items[i].SubItems[5].Text;//origine

                }
                // data += "</td><td width='5%'>";
                data += "|";

                if (listView1.Items[i].SubItems[6].Text.Length > 25)
                {

                    data += listView1.Items[i].SubItems[6].Text.Substring(0, 25);//admin
                }
                else
                {
                    data += listView1.Items[i].SubItems[6].Text;//admin
                }
                // data += "</td><td width='8%'>";
                data += "|";

                if (listView1.Items[i].SubItems[7].Text.Length < 10)
                {
                    data += "          ";
                }
                else
                {
                    data += listView1.Items[i].SubItems[7].Text;//telephone
                }
                // data += "</td><td width='5%'>";
                data += "|";
                data += listView1.Items[i].SubItems[8].Text;//date
                //   data += "</td></tr>";
                data += "\r\n";

                // data += "\r\n -----------------------------------\r\n";
            }
            // data += "</table>";


            SaveFileDialog s = new SaveFileDialog();
            s.Filter = "csv files (*.csv)|*.csv|All files (*.*)|*.*";
            s.FileName = "rewrite";
            if (s.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(s.OpenFile());

                writer.Write(data);


                writer.Close();

                //textBox3.Text = data;
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void repairAddressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string [] reg= new string []{ "rue","boulevard","avenue","place", "faubourg", "promenade","route", "all�e", "cit�", "passage", "cours", "quai", "square", "villa", "impasse", "chemin", "carrefour"};

            
            string road = "";
            string number = "";
            string voie = "";
            int sep = 0;
            int a = 0;
            int aa = 0;

            SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=" + datasrc + ";Integrated Security=True;Connect Timeout=30;User Instance=True");

            connection.Open();
            SqlCommand cmd = new SqlCommand("SELECT count(*) FROM BODACC where number is null", connection);

            int count = (int)cmd.ExecuteScalar();

           cmd = new SqlCommand("SELECT id, address FROM BODACC where number is null", connection);
        SqlDataReader rdr = cmd.ExecuteReader();
        


        while (rdr.Read())
        {
            try
            {
                a++;
                string address = (string)rdr["address"];
                address = address.ToLower();

                int id = (int)rdr["id"];

                for (int i = 0; i < reg.Length; i++)
                {
                    voie = "";
                    if (address.IndexOf(reg[i]) > -1)
                    {
                        voie = reg[i];
                        number = address.Substring(0, address.IndexOf(reg[i])).Replace("grande", string.Empty).Trim();
                        //   road = address.Substring(address.IndexOf(reg[i]) + voie.Length, address.Length - (address.IndexOf(reg[i]) + voie.Length));

                        break;
                    }

                }
                //    MessageBox.Show(address +" ==> "+ voie);

                if (number != "")
                {
                
                        road = address.Substring(address.IndexOf(number) + number.Length, address.Length - (address.IndexOf(number) + number.Length));

                        aa++;
                        if (aa > 10)
                        {
                            textBox3.Text = a.ToString() + " / " + count.ToString(); Application.DoEvents();
                            aa = 0;
                        }
                

                    if (road.Length > 0 && id > 0 && number.Length > 0)
                    {
                        SqlConnection connection1 = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=" + datasrc + ";Integrated Security=True;Connect Timeout=30;User Instance=True");

                        connection1.Open();


                        SqlCommand cmd1 = new SqlCommand("UPDATE BODACC SET address=@Road, voie=@Voie, number=@Number where id=@Id", connection1);// 1 =french
                        SqlParameter param = new SqlParameter();
                        param.ParameterName = "@Road";
                        param.Value = road.Trim();
                        cmd1.Parameters.Add(param);
                        param = new SqlParameter();
                        param.ParameterName = "@Id";
                        param.Value = id;
                        cmd1.Parameters.Add(param);
                        param = new SqlParameter();
                        param.ParameterName = "@Number";
                        param.Value = number.Trim();
                        cmd1.Parameters.Add(param);
                        param = new SqlParameter();
                        param.ParameterName = "@Voie";
                        param.Value = voie.Trim();
                        cmd1.Parameters.Add(param);

                        cmd1.ExecuteNonQuery();
                        connection1.Close();
                    }

                }
            }

            catch (Exception ex) {  }
        }
            
            MessageBox.Show("fini");


        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count <= 0)
            {
                return;
            }
            int i = listView1.SelectedIndices[0];

            string id = listView1.Items[i].SubItems[0].Text;


            SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=" + datasrc + ";Integrated Security=True;Connect Timeout=30;User Instance=True");

            connection.Open();
            SqlCommand cmd = new SqlCommand("SELECT count(*) FROM BODACC where number is null", connection);

            int count = (int)cmd.ExecuteScalar();

            cmd = new SqlCommand("DELETE FROM BODACC where id=@Id", connection);
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@Id";
            param.Value = id;
            cmd.Parameters.Add(param);

            cmd.ExecuteNonQuery();

            if (inputsearch.Text != "" || dept.Text != "")
            {
                read(inputsearch.Text, dept.Text, date.Text);

            }


        }



    }
}