﻿CREATE TABLE [dbo].[bodacc] (
    [id]             INT           IDENTITY (1, 1) NOT NULL,
    [company]        VARCHAR (MAX) NULL,
    [address]        VARCHAR (MAX) NULL,
    [dept]           VARCHAR (MAX) NULL,
    [description]    VARCHAR (MAX) NULL,
    [origine]        VARCHAR (MAX) NULL,
    [administration] VARBINARY(50) NULL,
    [phone]          VARCHAR (MAX) NULL,
    [date]           VARCHAR (MAX) NULL,
    [bodac_id]       INT           NULL,
    [number]         VARCHAR (50)  NULL,
    [voie]           VARCHAR (50)  NULL,
    [road]           VARCHAR (50)  NULL
);

